Comparision of immigrants 
where we compare immigrants with emigrants.